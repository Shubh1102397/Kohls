package kohls;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;

public class KohlsOrderTrackingTests {
    private WebDriver driver;
    private WebDriverWait wait;
    private final String BASE_URL = "https://www.kohls.com/";
    private final String TEST_EMAIL = "testuser@example.com";
    private final String TEST_PASSWORD = "password123";

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        driver.manage().window().maximize();
        driver.get(BASE_URL);
        
        // Login
        driver.findElement(By.linkText("Sign In")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email"))).sendKeys(TEST_EMAIL);
        driver.findElement(By.id("password")).sendKeys(TEST_PASSWORD);
        driver.findElement(By.xpath("//button[text()='Sign In']")).click();
        wait.until(ExpectedConditions.urlContains("account"));
    }

    @Test(priority=1)
    public void testOrderTracking() {
        driver.findElement(By.linkText("My Orders")).click();
        driver.findElement(By.xpath("//a[contains(text(),'Track')]")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Tracking')]")).isDisplayed());
    }

    @Test(priority=2)
    public void testReturnInitiation() {
        driver.findElement(By.linkText("My Orders")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Return')]")).click();
        driver.findElement(By.cssSelector("input[type='checkbox']")).click();
        new Select(driver.findElement(By.name("returnReason"))).selectByIndex(1);
        driver.findElement(By.xpath("//button[text()='Submit']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Return Label')]")).isDisplayed());
    }

    @Test(priority=3) 
    public void testReturnStatus() {
        driver.findElement(By.linkText("Returns")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Status')]")).isDisplayed());
    }

    @Test(priority=4)
    public void testInvalidOrderNumber() {
        driver.get(BASE_URL + "orderstatus.jsp");
        driver.findElement(By.id("orderNumber")).sendKeys("INVALID123");
        driver.findElement(By.xpath("//button[text()='Track']")).click();
        Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'not found')]")).isDisplayed());
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}