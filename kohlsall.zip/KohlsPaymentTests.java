package kohls;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;

public class KohlsPaymentTests {
    private WebDriver driver;
    private WebDriverWait wait;
    private final String BASE_URL = "https://www.kohls.com/";
    private final String TEST_PRODUCT = "Nike shoes";
    
    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(25));
        driver.manage().window().maximize();
        
        // Handle cookie consent
        driver.get(BASE_URL);
        try {
            WebElement acceptCookies = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Accept') or contains(text(),'AGREE')]")));
            acceptCookies.click();
        } catch (TimeoutException e) {
            System.out.println("Cookie banner not found, continuing without accepting");
        }
    }

    private void addProductToCart() {
        try {
            // Search for product
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@id='search' or @name='search' or @aria-label='Search']")));
            searchBox.clear();
            searchBox.sendKeys(TEST_PRODUCT);
            searchBox.sendKeys(Keys.RETURN);
            
            // Wait for search results to load
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[contains(@class,'products-grid') or contains(@class,'search-results')]")));
            
            // Open first available product
            WebElement firstProduct = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//a[contains(@href,'/product/') or contains(@class,'pdp-link')])[1]")));
            firstProduct.click();
            
            // Handle size selection if present
            try {
                WebElement sizeDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//select[@id='pdp-size-select' or contains(@class,'size-dropdown')]")));
                Select sizeSelect = new Select(sizeDropdown);
                sizeSelect.selectByIndex(1); // Select second available size
            } catch (TimeoutException e) {
                System.out.println("Size selection not required for this product");
            }
            
            // Add to cart
            WebElement addToCartBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Add to Cart') or contains(.,'Add to Bag')]")));
            addToCartBtn.click();
            
            // Wait for cart to update - check for either mini cart or count update
            try {
                wait.until(ExpectedConditions.or(
                    ExpectedConditions.visibilityOfElementLocated(
                        By.xpath("//div[contains(@class,'mini-cart') or contains(@class,'cart-preview')]")),
                    ExpectedConditions.textToBePresentInElementLocated(
                        By.xpath("//span[contains(@class,'cart-count') or contains(@class,'cart-quantity')]"), "1")
                ));
                System.out.println("Product successfully added to cart");
            } catch (TimeoutException e) {
                throw new AssertionError("Failed to verify product was added to cart");
            }
        } catch (Exception e) {
            takeScreenshot("addProductToCart_failure");
            throw e;
        }
    }

    private void proceedToCheckout() {
        try {
            // Go to cart
            WebElement cartIcon = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//a[contains(@class,'cart-icon') or contains(@href,'/cart/')]")));
            cartIcon.click();
            
            // Proceed to checkout
            WebElement checkoutBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Checkout') or contains(.,'Proceed to Checkout')]")));
            checkoutBtn.click();
            
            // Select guest checkout if available
            try {
                WebElement guestCheckout = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[contains(.,'Guest Checkout') or contains(.,'Checkout as Guest')]")));
                guestCheckout.click();
            } catch (TimeoutException e) {
                System.out.println("Guest checkout option not available, proceeding directly");
            }
        } catch (Exception e) {
            takeScreenshot("proceedToCheckout_failure");
            throw e;
        }
    }

    private void fillShippingInfo() {
        try {
            // Wait for shipping form to load
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//h2[contains(.,'Shipping') or contains(.,'Delivery')]")));
            
            // Fill shipping information
            WebElement firstName = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@id='firstName' or @name='firstName']")));
            firstName.sendKeys("Test");
            
            driver.findElement(By.xpath("//input[@id='lastName' or @name='lastName']")).sendKeys("User");
            driver.findElement(By.xpath("//input[@id='addressLine1' or @name='addressLine1']")).sendKeys("123 Test St");
            driver.findElement(By.xpath("//input[@id='city' or @name='city']")).sendKeys("Testville");
            
            // Select state
            WebElement stateDropdown = driver.findElement(
                By.xpath("//select[@id='state' or @name='state']"));
            new Select(stateDropdown).selectByVisibleText("California");
            
            driver.findElement(By.xpath("//input[@id='zipCode' or @name='zipCode']")).sendKeys("90001");
            driver.findElement(By.xpath("//input[@id='emailAddress' or @name='emailAddress']"))
                .sendKeys("testuser+" + System.currentTimeMillis() + "@example.com");
            driver.findElement(By.xpath("//input[@id='phone' or @name='phone']")).sendKeys("5551234567");
            
            // Continue to payment
            WebElement continueBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Continue to Payment') or contains(.,'Continue')]")));
            continueBtn.click();
            
            // Wait for payment section to load
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//h2[contains(.,'Payment') or contains(.,'Billing')]")));
        } catch (Exception e) {
            takeScreenshot("fillShippingInfo_failure");
            throw e;
        }
    }

    @Test(priority = 1, description = "TC13: Verify successful CC payment")
    public void testCreditCardPayment() {
        try {
            addProductToCart();
            proceedToCheckout();
            fillShippingInfo();
            
            // Enter credit card details (using test card numbers)
            WebElement cardNumber = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@id='cardNumber' or @name='cardNumber']")));
            cardNumber.sendKeys("4111111111111111");
            
            driver.findElement(By.xpath("//input[@id='cardExpirationDate' or @name='cardExpirationDate']"))
                .sendKeys("12/2025");
            driver.findElement(By.xpath("//input[@id='cardSecurityCode' or @name='cardSecurityCode']"))
                .sendKeys("123");
            
            // Verify place order button is present (but don't actually click it)
            WebElement placeOrderBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Place Order') or contains(.,'Complete Purchase')]")));
            
            System.out.println("TC13 Passed: Ready to place order with valid credit card");
        } catch (Exception e) {
            takeScreenshot("testCreditCardPayment_failure");
            throw new AssertionError("Credit card payment test failed: " + e.getMessage());
        }
    }

    @Test(priority = 2, description = "TC14: Verify PayPal integration")
    public void testPayPalPayment() {
        try {
            addProductToCart();
            proceedToCheckout();
            fillShippingInfo();
            
            // Select PayPal option
            WebElement paypalBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'PayPal') or contains(@class,'paypal-button')]")));
            paypalBtn.click();
            
            // Verify PayPal window opened
            try {
                wait.until(ExpectedConditions.numberOfWindowsToBe(2));
                System.out.println("TC14 Passed: PayPal integration working (window opened)");
                
                // Close PayPal window and return to main window
                for (String windowHandle : driver.getWindowHandles()) {
                    if (!windowHandle.equals(driver.getWindowHandle())) {
                        driver.switchTo().window(windowHandle);
                        driver.close();
                        break;
                    }
                }
                driver.switchTo().defaultContent();
            } catch (TimeoutException e) {
                throw new AssertionError("PayPal window did not open");
            }
        } catch (Exception e) {
            takeScreenshot("testPayPalPayment_failure");
            throw new AssertionError("PayPal payment test failed: " + e.getMessage());
        }
    }

    @Test(priority = 3, description = "TC15: Verify Kohl's Card payment")
    public void testKohlsCardPayment() {
        try {
            addProductToCart();
            proceedToCheckout();
            fillShippingInfo();
            
            // Select Kohl's Card option
            WebElement kohlsCardBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Kohl') and contains(.,'Card')]")));
            kohlsCardBtn.click();
            
            // Enter test Kohl's Card details
            WebElement cardNumber = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[contains(@id,'kohlsCardNumber') or contains(@name,'kohlsCardNumber')]")));
            cardNumber.sendKeys("4111111111111111");
            
            driver.findElement(By.xpath("//input[contains(@id,'kohlsCardExpirationDate')]"))
                .sendKeys("12/2025");
            driver.findElement(By.xpath("//input[contains(@id,'kohlsCardSecurityCode')]"))
                .sendKeys("123");
            
            // Verify payment method accepted (no error messages)
            try {
                wait.until(ExpectedConditions.invisibilityOfElementLocated(
                    By.xpath("//*[contains(text(),'Invalid') or contains(text(),'Error')]")));
                System.out.println("TC15 Passed: Kohl's Card payment method accepted");
            } catch (TimeoutException e) {
                throw new AssertionError("Kohl's Card payment failed");
            }
        } catch (Exception e) {
            takeScreenshot("testKohlsCardPayment_failure");
            throw new AssertionError("Kohl's Card payment test failed: " + e.getMessage());
        }
    }

    @Test(priority = 4, description = "TC16: Verify error for invalid card")
    public void testInvalidCardError() {
        try {
            addProductToCart();
            proceedToCheckout();
            fillShippingInfo();
            
            // Enter expired credit card details
            WebElement cardNumber = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@id='cardNumber' or @name='cardNumber']")));
            cardNumber.sendKeys("4111111111111111");
            
            driver.findElement(By.xpath("//input[@id='cardExpirationDate' or @name='cardExpirationDate']"))
                .sendKeys("01/2020");
            driver.findElement(By.xpath("//input[@id='cardSecurityCode' or @name='cardSecurityCode']"))
                .sendKeys("123");
            
            // Attempt to place order
            WebElement placeOrderBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Place Order') or contains(.,'Complete Purchase')]")));
            placeOrderBtn.click();
            
            // Verify error message
            try {
                WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//*[contains(text(),'Invalid') or contains(text(),'expired') or contains(text(),'Error')]")));
                System.out.println("TC16 Passed: Error displayed - " + errorMessage.getText());
            } catch (TimeoutException e) {
                throw new AssertionError("Invalid card error not displayed");
            }
        } catch (Exception e) {
            takeScreenshot("testInvalidCardError_failure");
            throw new AssertionError("Invalid card test failed: " + e.getMessage());
        }
    }

    private void takeScreenshot(String fileName) {
        try {
            byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            // In a real implementation, you would save this to a file
            System.out.println("Screenshot taken for failure: " + fileName);
        } catch (Exception e) {
            System.out.println("Failed to take screenshot: " + e.getMessage());
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}