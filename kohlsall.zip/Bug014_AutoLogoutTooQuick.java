package kohlsbug;

public class Bug014_AutoLogoutTooQuick {

}
