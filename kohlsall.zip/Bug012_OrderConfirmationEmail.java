package kohlsbug;

public class Bug012_OrderConfirmationEmail {

}
