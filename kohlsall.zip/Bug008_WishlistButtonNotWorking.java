package kohlsbug;

public class Bug008_WishlistButtonNotWorking {

}
