package kohlsbug;

public class Bug003_CouponFieldDisappears {

}
