package kohls;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;

public class KohlsCartTests {
    private WebDriver driver;
    private WebDriverWait wait;
    private final String BASE_URL = "https://www.kohls.com/";
    private final String TEST_EMAIL = "testuser+" + System.currentTimeMillis() + "@example.com";
    private final String TEST_PASSWORD = "SecurePassword123!";
    private final String TEST_PRODUCT = "Nike shoes"; // More generic search term
    
    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        driver.manage().window().maximize();
        
        // Handle cookie consent
        driver.get(BASE_URL);
        try {
            WebElement acceptCookies = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Accept') or contains(text(),'AGREE')]")));
            acceptCookies.click();
        } catch (TimeoutException e) {
            System.out.println("Cookie banner not found, continuing without accepting");
        }
    }

    @Test(priority = 1, description = "TC09: Verify adding item to cart")
    public void testAddToCart() {
        try {
            // Search for product
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[@id='search' or @name='search' or @aria-label='Search']")));
            searchBox.clear();
            searchBox.sendKeys(TEST_PRODUCT);
            searchBox.sendKeys(Keys.RETURN);
            
            // Wait for search results to load
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[contains(@class,'products-grid')]")));
            
            // Open first available product
            WebElement firstProduct = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//div[contains(@class,'product-grid')]//a[contains(@href,'/product/')])[1]")));
            firstProduct.click();
            
            // Handle size selection if present
            try {
                WebElement sizeDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//select[@id='pdp-size-select' or contains(@class,'size-dropdown')]")));
                Select sizeSelect = new Select(sizeDropdown);
                sizeSelect.selectByIndex(1); // Select second available size
            } catch (TimeoutException e) {
                System.out.println("Size selection not required for this product");
            }
            
            // Add to cart
            WebElement addToCartBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Add to Cart') or contains(.,'Add to Bag')]")));
            addToCartBtn.click();
            
            // Verify cart update - wait for either mini cart to appear or count to update
            try {
                // Option 1: Check for mini cart
                wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//div[contains(@class,'mini-cart') or contains(@class,'cart-preview')]")));
                
                // Option 2: Check cart count
                WebElement cartCount = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//span[contains(@class,'cart-count') or contains(@class,'cart-quantity')]")));
                System.out.println("TC09 Passed: Item successfully added to cart. Cart count: " + cartCount.getText());
            } catch (TimeoutException e) {
                throw new AssertionError("Failed to verify cart update after adding item");
            }
        } catch (Exception e) {
            // Take screenshot on failure
            takeScreenshot("testAddToCart_failure");
            throw e;
        }
    }

    @Test(priority = 2, description = "TC10: Verify quantity update in cart", dependsOnMethods = "testAddToCart")
    public void testUpdateCartQuantity() {
        try {
            // Open cart
            WebElement cartIcon = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//a[contains(@class,'cart-icon') or contains(@href,'/cart/')]")));
            cartIcon.click();
            
            // Wait for cart page to load
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//h1[contains(.,'Your Shopping Cart') or contains(.,'Cart')]")));
            
            // Update quantity
            WebElement quantityDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//select[contains(@class,'qty-dropdown') or contains(@name,'quantity')]")));
            Select quantitySelect = new Select(quantityDropdown);
            quantitySelect.selectByVisibleText("2");
            
            // Click update button if present (some sites update automatically)
            try {
                WebElement updateBtn = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[contains(.,'Update')]")));
                updateBtn.click();
                wait.until(ExpectedConditions.invisibilityOf(updateBtn));
            } catch (TimeoutException e) {
                System.out.println("Quantity updated automatically without Update button");
            }
            
            // Verify quantity updated
            wait.until(ExpectedConditions.textToBePresentInElementValue(
                By.xpath("//select[contains(@class,'qty-dropdown')]"), "2"));
            
            System.out.println("TC10 Passed: Quantity updated successfully");
        } catch (Exception e) {
            takeScreenshot("testUpdateCartQuantity_failure");
            throw e;
        }
    }

    @Test(priority = 3, description = "TC11: Verify guest checkout option", dependsOnMethods = "testUpdateCartQuantity")
    public void testGuestCheckout() {
        try {
            // Proceed to checkout
            WebElement checkoutBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Checkout') or contains(.,'Proceed to Checkout')]")));
            checkoutBtn.click();
            
            // Select guest checkout
            WebElement guestCheckout = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Guest Checkout') or contains(.,'Checkout as Guest')]")));
            guestCheckout.click();
            
            // Verify we're on shipping information page
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//h2[contains(.,'Shipping') or contains(.,'Delivery')]")));
            
            System.out.println("TC11 Passed: Reached guest checkout shipping page");
            
            // Don't actually complete checkout in test
            driver.navigate().back();
        } catch (Exception e) {
            takeScreenshot("testGuestCheckout_failure");
            throw e;
        }
    }

    @Test(priority = 4, description = "TC12: Verify cart persistence after logout", dependsOnMethods = "testGuestCheckout")
    public void testCartPersistence() {
        try {
            // Get current cart count
            String initialCartCount = driver.findElement(
                By.xpath("//span[contains(@class,'cart-count') or contains(@class,'cart-quantity')]")).getText();
            
            // Logout
            WebElement accountMenu = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//a[contains(.,'My Account') or contains(.,'Account')]")));
            accountMenu.click();
            
            WebElement signOut = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//a[contains(.,'Sign Out') or contains(.,'Log Out')]")));
            signOut.click();
            
            // Verify logged out
            wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//a[contains(.,'Sign In') or contains(.,'Log In')]")));
            
            // Verify cart count remains
            String currentCartCount = driver.findElement(
                By.xpath("//span[contains(@class,'cart-count') or contains(@class,'cart-quantity')]")).getText();
            
            if (!currentCartCount.equals(initialCartCount)) {
                throw new AssertionError("Cart count changed after logout. Before: " + 
                    initialCartCount + ", After: " + currentCartCount);
            }
            
            System.out.println("TC12 Passed: Cart count persisted after logout");
        } catch (Exception e) {
            takeScreenshot("testCartPersistence_failure");
            throw e;
        }
    }

    private void takeScreenshot(String fileName) {
        try {
            byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            // Save screenshot logic here (you can implement file saving if needed)
            System.out.println("Screenshot taken for failure: " + fileName);
        } catch (Exception e) {
            System.out.println("Failed to take screenshot: " + e.getMessage());
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}