package kohlsbug;

public class Bug010_PayPalMissingCheckout {

}
