package kohls;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

public class KohlsMobileTests {

    private WebDriver driver;
    private WebDriverWait wait;
    private final String BASE_URL = "https://www.kohls.com/";

    @BeforeClass
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver"); // Replace with actual path

        Map<String, String> mobileEmulation = new HashMap<>();
        mobileEmulation.put("deviceName", "Pixel 2");

        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);

        driver = new ChromeDriver(chromeOptions);
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        driver.get(BASE_URL);
    }

    @Test(priority = 1)
    public void testMobileMenu() {
        WebElement menuButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@aria-label='Menu']")));
        menuButton.click();

        WebElement mobileMenu = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("kds-SideNav")));
        Assert.assertTrue(mobileMenu.isDisplayed());

        WebElement closeButton = driver.findElement(By.xpath("//button[@aria-label='Close']"));
        closeButton.click();
    }

    @Test(priority = 2)
    public void testMobileSearch() {
        WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@aria-label='Search']")));
        searchButton.click();

        WebElement searchInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("search-input")));
        searchInput.sendKeys("Nike shoes");

        WebElement submitBtn = driver.findElement(By.xpath("//button[@type='submit']"));
        submitBtn.click();

        WebElement searchResult = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div[data-testid='product-grid']")));
        Assert.assertTrue(searchResult.isDisplayed());
    }

    @Test(priority = 3)
    public void testAddToCartAndCheckout() {
        WebElement firstProduct = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[contains(@class,'product')])[1]")));
        firstProduct.click();

        WebElement addToCart = wait.until(ExpectedConditions.elementToBeClickable(By.id("add-to-cart")));
        addToCart.click();

        WebElement cartIcon = wait.until(ExpectedConditions.elementToBeClickable(By.id("cart-icon")));
        cartIcon.click();

        WebElement checkoutButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("checkout")));
        checkoutButton.click();

        wait.until(ExpectedConditions.urlContains("checkout"));
        Assert.assertTrue(driver.getCurrentUrl().contains("checkout"));
    }

    @Test(priority = 4)
    public void testWishlistPromptWithoutLogin() {
        WebElement firstProduct = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[contains(@class,'product')])[1]")));
        firstProduct.click();

        WebElement wishlistButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[aria-label*='Save']")));
        wishlistButton.click();

        WebElement loginPrompt = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div[class*='signin']")));
        Assert.assertTrue(loginPrompt.isDisplayed());
    }
    
    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
