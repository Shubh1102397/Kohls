package kohls;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import static org.testng.Assert.*;

public class KohlsSupportTests {
    private WebDriver driver;
    private WebDriverWait wait;
    private final String BASE_URL = "https://www.kohls.com/";
    private final Duration TIMEOUT = Duration.ofSeconds(20);

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, TIMEOUT);
        driver.manage().window().maximize();
        driver.get(BASE_URL);
        acceptCookies();
    }

    private void acceptCookies() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Accept')]"))).click();
        } catch (Exception e) {
            System.out.println("No cookie banner found");
        }
    }

    @Test(priority=1)
    public void testLiveChat() {
        try {
            // Navigate to contact page
            driver.findElement(By.xpath("//a[contains(.,'Customer Service') or contains(.,'Contact')]")).click();
            
            // Try to find chat button with multiple possible locators
            WebElement chatButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Chat')][contains(.,'Now') or contains(.,'Live')]")));
            chatButton.click();
            
            // Switch to chat iframe if exists
            try {
                wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(
                    By.cssSelector("iframe[title*='chat'], iframe[title*='LiveChat']")));
                
                WebElement chatInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.cssSelector("textarea, input[type='text']")));
                chatInput.sendKeys("Hello, I need help" + Keys.ENTER);
                
                boolean gotResponse = wait.until(ExpectedConditions.textToBePresentInElementLocated(
                    By.cssSelector(".agent-message, .response"), "Hi"));
                
                assertTrue(gotResponse, "No chat response received");
            } finally {
                driver.switchTo().defaultContent();
            }
        } catch (Exception e) {
            fail("Live chat test failed: " + e.getMessage());
        }
    }

    @Test(priority=2)
    public void testContactForm() {
        try {
            // Navigate to contact page
            driver.findElement(By.xpath("//a[contains(.,'Customer Service') or contains(.,'Contact')]")).click();
            driver.findElement(By.xpath("//a[contains(.,'Email') or contains(.,'Form')]")).click();
            
            // Fill form with more flexible field finding
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[contains(@id,'name') or contains(@name,'name')]"))).sendKeys("Test");
            
            driver.findElement(By.xpath("//input[contains(@id,'email')]")).sendKeys("test@example.com");
            driver.findElement(By.xpath("//textarea")).sendKeys("Test query");
            driver.findElement(By.xpath("//button[contains(.,'Submit')]")).click();
            
            assertTrue(wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[contains(text(),'success') or contains(text(),'thank you')]"))).isDisplayed(), 
                "No confirmation shown");
        } catch (Exception e) {
            fail("Contact form test failed: " + e.getMessage());
        }
    }

    @Test(priority=3) 
    public void testFaqSearch() {
        try {
            // Navigate to help center
            driver.findElement(By.xpath("//a[contains(.,'Help') or contains(.,'FAQ')]")).click();
            
            // Search with more flexible input finding
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[contains(@name,'search') or contains(@placeholder,'search')]")));
            searchBox.sendKeys("return policy" + Keys.ENTER);
            
            assertTrue(wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[contains(@class,'result') or contains(@class,'article')]"))).isDisplayed(), 
                "No FAQ results found");
        } catch (Exception e) {
            fail("FAQ search test failed: " + e.getMessage());
        }
    }

    @Test(priority=4)
    public void testCallback() {
        try {
            // Navigate to contact page
            driver.findElement(By.xpath("//a[contains(.,'Customer Service') or contains(.,'Contact')]")).click();
            driver.findElement(By.xpath("//a[contains(.,'Callback') or contains(.,'Call Back')]")).click();
            
            // Fill form with more flexible field finding
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//input[contains(@id,'phone') or contains(@name,'phone')]"))).sendKeys("5551234567");
            
            driver.findElement(By.xpath("//button[contains(.,'Request')]")).click();
            
            assertTrue(wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[contains(text(),'scheduled') or contains(text(),'confirmation')]"))).isDisplayed(),
                "Callback confirmation not shown");
        } catch (Exception e) {
            fail("Callback test failed: " + e.getMessage());
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}