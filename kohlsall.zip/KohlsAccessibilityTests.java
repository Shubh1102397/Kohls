package kohls;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import java.util.List;

public class KohlsAccessibilityTests {
    private WebDriver driver;
    private WebDriverWait wait;
    private final String BASE_URL = "https://www.kohls.com/";

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        driver.manage().window().maximize();
        driver.get(BASE_URL);
        
        // Accept cookies if present
        try {
            WebElement acceptCookies = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Accept')]")));
            acceptCookies.click();
        } catch (TimeoutException e) {
            // Cookie banner not found, continue
        }
    }

    @Test(priority=1)
    public void testScreenReaderElements() {
        try {
            // Verify skip link exists (but don't fail if not found)
            List<WebElement> skipLinks = driver.findElements(By.xpath("//a[contains(.,'Skip')]"));
            if (skipLinks.isEmpty()) {
                System.out.println("Warning: Skip link not found");
            }
            
            // Verify images have alt text (skip decorative images)
            List<WebElement> images = driver.findElements(By.tagName("img"));
            for (WebElement img : images) {
                String alt = img.getAttribute("alt");
                String src = img.getAttribute("src");
                
                // Skip placeholder and decorative images
                if (src.contains("placeholder") || src.contains("spacer")) {
                    continue;
                }
                
                if (alt == null || alt.trim().isEmpty()) {
                    throw new AssertionError("Missing alt text for image: " + src);
                }
            }
        } catch (Exception e) {
            throw new AssertionError("Screen reader test failed: " + e.getMessage());
        }
    }

    @Test(priority=2) 
    public void testKeyboardNavigation() {
        try {
            // Start tabbing from the beginning
            driver.findElement(By.tagName("body")).sendKeys(Keys.HOME);
            
            // Tab through elements and check focus
            for (int i = 0; i < 10; i++) {
                driver.switchTo().activeElement().sendKeys(Keys.TAB);
                WebElement focused = driver.switchTo().activeElement();
                
                // Skip body element
                if (focused.getTagName().equals("body")) {
                    continue;
                }
                
                String outline = focused.getCssValue("outline");
                if (outline == null || outline.equals("none")) {
                    throw new AssertionError("Missing focus indicator on: " + 
                        focused.getTagName() + " with text: " + focused.getText());
                }
            }
        } catch (Exception e) {
            throw new AssertionError("Keyboard navigation test failed: " + e.getMessage());
        }
    }

    @Test(priority=3)
    public void testColorContrast() {
        try {
            // This is a placeholder - in real tests use axe-core
            System.out.println("Color contrast checks would be implemented with axe-core");
        } catch (Exception e) {
            throw new AssertionError("Color contrast test failed: " + e.getMessage());
        }
    }

    @Test(priority=4)
    public void testZoomCompatibility() {
        try {
            // Zoom to 150%
            JavascriptExecutor js = (JavascriptExecutor)driver;
            js.executeScript("document.body.style.zoom='150%'");
            
            // Wait for resize
            Thread.sleep(1000);
            
            // Check for horizontal scrolling
            boolean hasHorizontalScroll = (Boolean)js.executeScript(
                "return document.documentElement.scrollWidth > document.documentElement.clientWidth");
            
            if (hasHorizontalScroll) {
                System.out.println("Warning: Horizontal scrolling required at 150% zoom");
                // Don't fail the test - this is common on many sites
            }
        } catch (Exception e) {
            throw new AssertionError("Zoom compatibility test failed: " + e.getMessage());
        } finally {
            // Reset zoom
            JavascriptExecutor js = (JavascriptExecutor)driver;
            js.executeScript("document.body.style.zoom='100%'");
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}