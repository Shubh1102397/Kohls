package kohlsbug;

public class Bug009_BrokenFooterLink {

}
