package kohlsbug;

public class Bug002_BrokenImagesShort {

}
