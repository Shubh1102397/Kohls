package kohls;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;

public class KohlsUserTests {
    private WebDriver driver;
    private WebDriverWait wait;
    private final String BASE_URL = "https://www.kohls.com/";
    private final String TEST_EMAIL = "testuser+" + System.currentTimeMillis() + "@example.com";
    private final String TEST_PASSWORD = "SecurePassword123!";
    private final String TEST_FIRST_NAME = "Test";
    private final String TEST_LAST_NAME = "User";

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // Increased wait time
        driver.manage().window().maximize();
    }

    @Test(priority = 1, description = "Verify new user registration")
    public void testUserRegistration() {
        driver.get(BASE_URL);
        
        // Handle cookie consent if present //
        try {
            WebElement acceptCookies = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Accept') or contains(text(),'ACCEPT')]")));
            acceptCookies.click();
        } catch (TimeoutException e) {
            // No cookie banner found, continue //
        }
        
        // Click on Sign In first Sign Up might be inside the Sign In dropdown //
        wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Sign In"))).click();
        
        // Then click on Sign Up //
        try {
            wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Sign Up"))).click();
        } catch (TimeoutException e) {
            // Try alternative locator //
            wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//a[contains(text(),'Create an account')]"))).click();
        }
        
        // Fill registration form //
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email"))).sendKeys(TEST_EMAIL);
        driver.findElement(By.id("password")).sendKeys(TEST_PASSWORD);
        driver.findElement(By.id("firstName")).sendKeys(TEST_FIRST_NAME);
        driver.findElement(By.id("lastName")).sendKeys(TEST_LAST_NAME);
        
        // Submit registration //
        driver.findElement(By.xpath("//button[contains(text(),'Create Account')]")).click();
        
        // Verify successful registration //
        try {
            WebElement successMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[contains(text(),'Welcome') or contains(text(),'success')]")));
            System.out.println("Registration successful: " + successMessage.getText());
        } catch (TimeoutException e) {
            throw new AssertionError("Registration failed - success message not displayed");
        }
    }

    // Rest of your test methods remain the same //

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}