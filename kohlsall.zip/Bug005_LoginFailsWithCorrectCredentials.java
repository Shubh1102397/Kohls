package kohlsbug;

public class Bug005_LoginFailsWithCorrectCredentials {

}
