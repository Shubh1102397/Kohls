package kohls;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import static org.testng.Assert.*;

import java.time.LocalDate;

public class KohlsPromoTests {
    private WebDriver driver;
    private final String BASE_URL = "https://www.kohls.com/";

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(BASE_URL);
        acceptCookies();
        addTestProduct();
    }

    private void acceptCookies() {
        try {
            driver.findElement(By.xpath("//button[contains(.,'Accept')]")).click();
        } catch (Exception e) { /* Ignore if no cookie banner */ }
    }

    private void addTestProduct() {
        driver.findElement(By.id("search")).sendKeys("Nike shoes" + Keys.ENTER);
        driver.findElement(By.cssSelector(".pdp-link")).click();
        driver.findElement(By.cssSelector(".add-to-cart")).click();
    }

    @Test(priority=1)
    public void verifyValidCoupon() {
        applyCoupon("SAVE20");
        assertTrue(driver.findElement(By.cssSelector(".discount-amount")).isDisplayed(), 
                 "Discount not applied");
    }

    @Test(priority=2)
    public void verifyNonCombinablePromos() {
        applyCoupon("FREESHIP");
        applyKohlsCash();
        assertEquals(driver.findElements(By.cssSelector(".active-promo")).size(), 1, 
                   "Multiple discounts applied incorrectly");
    }

    @Test(priority=3) 
    public void verifyExpiredCoupon() {
        applyCoupon("OLDCODE");
        assertTrue(driver.findElement(By.cssSelector(".promo-error")).getText()
                 .toLowerCase().contains("invalid"), "No error for expired coupon");
    }

    @Test(priority=4)
    public void verifySeasonalPromo() {
        driver.get(BASE_URL);
        boolean isBlackFriday = LocalDate.now().getMonthValue() == 11 && 
                              LocalDate.now().getDayOfMonth() <= 30;
        assertEquals(driver.findElements(By.cssSelector(".blackfriday-banner")).isEmpty(), 
                   !isBlackFriday, "Promo banner visibility mismatch");
    }

    private void applyCoupon(String code) {
        driver.findElement(By.id("promo-code")).clear();
        driver.findElement(By.id("promo-code")).sendKeys(code);
        driver.findElement(By.cssSelector(".apply-promo")).click();
    }

    private void applyKohlsCash() {
        driver.findElement(By.cssSelector(".kohls-cash-btn")).click();
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}