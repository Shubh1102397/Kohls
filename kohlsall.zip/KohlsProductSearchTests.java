package kohls;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import java.util.List;

public class KohlsProductSearchTests {
    private WebDriver driver;
    private WebDriverWait wait;
    private final String BASE_URL = "https://www.kohls.com/";
    private final String SEARCH_KEYWORD = "Nike shoes";
    private final String OOS_PRODUCT_SKU = "12345678"; // Replace with actual OOS SKU

    @BeforeClass
    public void setUp() {
        // Use WebDriverManager to automatically handle chromedriver
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // Increased wait time
        driver.manage().window().maximize();
        
        // Handle potential cookie consent
        driver.get(BASE_URL);
        try {
            WebElement acceptCookies = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Accept') or contains(text(),'ACCEPT')]")));
            acceptCookies.click();
        } catch (TimeoutException e) {
            // Cookie banner not found, continue
        }
    }

    @Test(priority = 1, description = "Verify product search by keyword")
    public void testKeywordSearch() {
        driver.get(BASE_URL);
        
        // Enter search keyword and submit
        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//input[@id='search' or @name='search' or contains(@class,'search-input')]")));
        searchBox.clear();
        searchBox.sendKeys(SEARCH_KEYWORD);
        searchBox.sendKeys(Keys.RETURN);
        
        // Wait for results to load
        wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.cssSelector(".products-grid, .search-results")));
        
        // Verify search results
        try {
            WebElement resultsHeader = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//h1[contains(text(),'results for') or contains(text(),'Search Results')]")));
            System.out.println("Search results displayed for: " + resultsHeader.getText());
            
            // Verify at least one product contains the search keyword
            List<WebElement> products = driver.findElements(By.cssSelector(".product-title, .prod-name-block"));
            if (products.isEmpty()) {
                throw new AssertionError("No products found on search results page");
            }
            
            boolean keywordFound = products.stream()
                .anyMatch(p -> p.getText().toLowerCase().contains(SEARCH_KEYWORD.toLowerCase()));
            
            if (!keywordFound) {
                throw new AssertionError("No products found matching the search keyword");
            }
        } catch (TimeoutException e) {
            throw new AssertionError("Search results not displayed properly");
        }
    }

    @Test(priority = 2, description = "Verify filtering by category", dependsOnMethods = "testKeywordSearch")
    public void testCategoryFilter() {
        // Apply Men's Clothing filter
        try {
            // Open category filter
            WebElement categoryFilter = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(.,'Category') or contains(.,'Department')]")));
            categoryFilter.click();
            
            // Select Men's Clothing
            WebElement mensClothing = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//a[contains(.,'Men') and contains(.,'Clothing') or contains(.,'Men') and contains(.,'Apparel')]")));
            mensClothing.click();
            
            // Wait for results to update
            wait.until(ExpectedConditions.invisibilityOfElementLocated(
                By.cssSelector(".loading-indicator, .loader, .spinner")));
            
            // Verify filtered results
            List<WebElement> filteredProducts = driver.findElements(
                By.cssSelector(".product-title, .prod-name-block"));
            
            if (filteredProducts.isEmpty()) {
                throw new AssertionError("No products found after applying filter");
            }
            
            boolean allMatchCategory = filteredProducts.stream()
                .anyMatch(p -> p.getText().toLowerCase().contains("men"));
            
            if (!allMatchCategory) {
                throw new AssertionError("Not all products match the selected category filter");
            }
            System.out.println("Category filter applied successfully");
        } catch (TimeoutException e) {
            throw new AssertionError("Failed to apply category filter");
        }
    }

    @Test(priority = 3, description = "Verify sorting by price (Low-High)", dependsOnMethods = "testKeywordSearch")
    public void testPriceSorting() {
        // Apply price sorting
        try { 
            // Open sort dropdown
            WebElement sortDropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//select[@id='sort' or contains(@class,'sort-select') or contains(@aria-label,'Sort by')]")));
            Select sortSelect = new Select(sortDropdown);
            
            // Select Price Low-High
            sortSelect.selectByVisibleText("Price: Low-High");
            
            // Wait for results to update
            wait.until(ExpectedConditions.invisibilityOfElementLocated(
                By.cssSelector(".loading-indicator, .loader, .spinner")));
            
            // Verify sorting
            List<WebElement> priceElements = driver.findElements(
                By.cssSelector(".product-price, .prod-price-amount"));
            
            if (priceElements.isEmpty()) {
                throw new AssertionError("No price elements found after sorting");
            }
            
            double previousPrice = 0;
            boolean isSorted = true;
            
            for (WebElement priceElement : priceElements) {
                String priceText = priceElement.getText().replaceAll("[^0-9.]", "");
                if (priceText.isEmpty()) continue;
                
                double currentPrice = Double.parseDouble(priceText);
                
                if (currentPrice < previousPrice) {
                    isSorted = false;
                    break;
                }
                previousPrice = currentPrice;
            }
            
            if (!isSorted) {
                throw new AssertionError("Products are not sorted by price (Low-High)");
            }
            System.out.println("Price sorting applied successfully");
        } catch (TimeoutException e) {
            throw new AssertionError("Failed to apply price sorting");
        }
    }

    @Test(priority = 4, description = "Verify behavior for out-of-stock items")
    public void testOutOfStockItem() {
        driver.get(BASE_URL);
        
        // Search for OOS product
        WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//input[@id='search' or @name='search' or contains(@class,'search-input')]")));
        searchBox.clear();
        searchBox.sendKeys(OOS_PRODUCT_SKU);
        searchBox.sendKeys(Keys.RETURN);
        
        // Open product page
        try {
            WebElement productLink = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector(".product-title, .prod-name-block")));
            productLink.click();
            
            // Verify OOS label
            WebElement oosLabel = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[contains(text(),'Out of Stock') or contains(text(),'Not Available') or contains(text(),'Unavailable')]")));
            System.out.println("Out of Stock verification: " + oosLabel.getText());
        } catch (TimeoutException e) {
            throw new AssertionError("Out of Stock indicator not found");
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}