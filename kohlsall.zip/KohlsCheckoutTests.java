package kohls;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
import java.util.List;

public class KohlsCheckoutTests {
	WebDriver driver;
    WebDriverWait wait;
    private static final String BASE_URL = "https://www.kohls.com/";
    private static final String CHROME_DRIVER_PATH = "path/to/chromedriver";
    
    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", CHROME_DRIVER_PATH);
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }
    
    @Test(priority = 1, description = "TC41: Verify checkout with empty cart")
    public void verifyEmptyCartCheckout() {
        driver.get(BASE_URL);
        
        // Go directly to checkout (which should show cart) //
        driver.get(BASE_URL + "checkout.jsp");
        
        // Verify empty cart message //
        WebElement emptyCartMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//*[contains(text(),'Your cart is empty') or contains(text(),'empty')]")));
        Assert.assertTrue(emptyCartMessage.isDisplayed(), "Empty cart message not displayed");
    }
    
    @Test(priority = 2, description = "TC42: Verify 100-item order")
    public void verifyHighVolumeOrder() throws InterruptedException {
        // This test assumes we have a way to add 100 items to cart //
      
        
        // Navigate to a test product page //
        driver.get(BASE_URL + "product/prd-123456/some-test-product.jsp");
        
        // Set quantity to 100 and add to cart //
        WebElement quantityInput = wait.until(ExpectedConditions.elementToBeClickable(
            By.id("qty")));
        quantityInput.clear();
        quantityInput.sendKeys("100");
        
        WebElement addToCartBtn = driver.findElement(By.id("addToCart"));
        addToCartBtn.click();
        
        // Proceed to checkout //
        WebElement checkoutBtn = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//a[contains(text(),'Checkout')]")));
        checkoutBtn.click();
        
        // Verify cart has 100 items //
        WebElement itemCount = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//span[contains(@class,'item-count')]")));
        Assert.assertEquals(itemCount.getText(), "100", "Item count mismatch");
        
        // Complete payment (simplified - would need actual test payment details) //
        // This part would need to be adjusted based on actual checkout flow //
        try {
            WebElement placeOrderBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("placeOrder")));
            placeOrderBtn.click();
            
            WebElement confirmation = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[contains(text(),'Thank you for your order')]")));
            Assert.assertTrue(confirmation.isDisplayed(), "Order confirmation not displayed");
        } catch (Exception e) {
            Assert.fail("Order processing failed: " + e.getMessage());
        }
    }
    
    @Test(priority = 3, description = "TC43: Verify non-US address error")
    public void verifyInternationalShippingError() {
        driver.get(BASE_URL + "checkout.jsp");
        
        // Add a test item if needed (might need setup) //
        
        
        // Enter Canadian address //
        WebElement countryDropdown = wait.until(ExpectedConditions.elementToBeClickable(
            By.id("country")));
        countryDropdown.sendKeys("Canada");
        
        WebElement addressInput = driver.findElement(By.id("address1"));
        addressInput.sendKeys("123 Test St");
        
        WebElement cityInput = driver.findElement(By.id("city"));
        cityInput.sendKeys("Toronto");
        
        WebElement provinceInput = driver.findElement(By.id("state"));
        provinceInput.sendKeys("ON");
        
        WebElement zipInput = driver.findElement(By.id("zipCode"));
        zipInput.sendKeys("M5V 3L9");
        
        // Check shipping options //
        WebElement shippingBtn = driver.findElement(By.id("shippingSubmit"));
        shippingBtn.click();
        
        // Verify US only error //
        WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//*[contains(text(),'US only') or contains(text(),'not ship')]")));
        Assert.assertTrue(errorMessage.isDisplayed(), "International shipping error not displayed");
    }
    
    @Test(priority = 4, description = "TC44: Verify session timeout handling")
    public void verifySessionTimeoutHandling() throws InterruptedException {
        // First login (would need valid test credentials) //
        driver.get(BASE_URL + "account/login.jsp");
        WebElement emailInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));
        emailInput.sendKeys("testuser@example.com");
        WebElement passwordInput = driver.findElement(By.id("password"));
        passwordInput.sendKeys("test123");
        WebElement loginBtn = driver.findElement(By.id("signIn"));
        loginBtn.click();
        
        // Add item to cart //
        driver.get(BASE_URL + "product/prd-123456/some-test-product.jsp");
        WebElement addToCartBtn = wait.until(ExpectedConditions.elementToBeClickable(By.id("addToCart")));
        addToCartBtn.click();
        
        // Wait for timeout (30 minutes) - in real test you might need to force session expiration
        // For demo, we'll just simulate by clearing session cookies //
        Thread.sleep(2000);
        
        // Force session expiration (alternative would be to wait actual 30 mins) //
        driver.manage().deleteAllCookies();
        
        // Try to check out //
        driver.get(BASE_URL + "checkout.jsp");
        
        // Verify login prompt appears //
        WebElement loginPrompt = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//*[contains(text(),'Sign in') or contains(text(),'log in')]")));
        Assert.assertTrue(loginPrompt.isDisplayed(), "Login prompt not displayed after timeout");
        
        // Verify cart is intact after login (would need to complete login) //
        // This part would need to be expanded based on actual flow //
    }
    
    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
