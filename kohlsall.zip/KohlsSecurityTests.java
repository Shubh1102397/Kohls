package kohls;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;
import java.time.Duration;

public class KohlsSecurityTests {
    private WebDriver driver;
    private WebDriverWait wait;
    private final String BASE_URL = "https://www.kohls.com/";
    private final long MAX_LOAD_TIME = 3000; // 3 seconds

    @BeforeClass
    public void setup() {
        // 1. ACTUAL CHROMEDRIVER PATH - UPDATE THIS
        System.setProperty("webdriver.chrome.driver", "C:\\webdrivers\\chromedriver.exe");
        
        // 2. ENHANCED CHROME OPTIONS
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");
        options.setHeadless(false); // Set to true for CI environments
        
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    @Test(priority = 1)
    public void verifySSLCertificate() {
        driver.get(BASE_URL);
        Assert.assertTrue(driver.getCurrentUrl().startsWith("https://"), 
            "Site should use HTTPS");
        System.out.println("SSL Certificate Verified");
    }

    @Test(priority = 2)
    public void verifyPageLoadTime() {
        // Clear browser cache more thoroughly
        driver.manage().deleteAllCookies();
        ((JavascriptExecutor)driver).executeScript("window.localStorage.clear();");
        
        long start = System.currentTimeMillis();
        driver.get(BASE_URL);
        wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.cssSelector("header, footer, #navigation")));
        
        long loadTime = System.currentTimeMillis() - start;
        System.out.println("Page loaded in " + loadTime + "ms");
        Assert.assertTrue(loadTime <= MAX_LOAD_TIME, 
            "Load time " + loadTime + "ms exceeds 3 seconds");
    }

    @Test(priority = 3)
    public void testSQLInjectionProtection() {
        driver.get(BASE_URL);
        try {
            WebElement search = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("input[type='search'], #search")));
            search.sendKeys("' OR 1=1--", Keys.RETURN);
            
            WebElement result = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".error-message, .search-results, .no-results")));
            
            System.out.println("SQL Injection Test Response: " + result.getText());
            Assert.assertFalse(result.getText().contains("error in your SQL syntax"), 
                "Potential SQL injection vulnerability detected");
        } catch (TimeoutException e) {
            Assert.fail("No response detected for SQL injection attempt");
        }
    }

    @Test(priority = 4)
    public void testBruteForceProtection() {
        driver.get(BASE_URL + "account/login.jsp");
        try {
            WebElement email = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("input[type='email'], #email")));
            WebElement pwd = driver.findElement(
                By.cssSelector("input[type='password'], #password"));
            WebElement submit = driver.findElement(
                By.cssSelector("button[type='submit'], #signInSubmit"));
            
            email.sendKeys("testuser@example.com");
            
            for (int i = 1; i <= 5; i++) {
                pwd.sendKeys("wrongpassword" + i);
                submit.click();
                
                // Wait for error message after each attempt
                try {
                    WebElement error = wait.withTimeout(Duration.ofSeconds(2))
                        .until(ExpectedConditions.visibilityOfElementLocated(
                            By.cssSelector(".error-message, .alert")));
                    
                    System.out.println("Attempt " + i + ": " + error.getText());
                    
                    if (i == 5) {
                        Assert.assertTrue(
                            error.getText().toLowerCase().contains("locked") || 
                            error.getText().toLowerCase().contains("temporarily"),
                            "Account lock message not found after 5 attempts");
                    }
                } catch (TimeoutException e) {
                    if (i == 5) {
                        Assert.fail("No error message detected after 5 attempts");
                    }
                }
                wait.withTimeout(Duration.ofSeconds(15));
            }
        } catch (NoSuchElementException e) {
            Assert.fail("Login form elements not found: " + e.getMessage());
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}